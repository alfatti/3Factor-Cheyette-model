"""Execute the notebooks in place (python run_all.py [names...]); set CHEYETTE_FAST=1 for a smoke test."""
import sys, os, time, nbformat
from nbclient import NotebookClient
names = sys.argv[1:] or ["01_bonds", "02_caplets", "03_vanilla_swaps", "04_european_swaptions", "05_bermudan_swaptions"]
for n in names:
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), n + ".ipynb")
    nb = nbformat.read(path, as_version=4)
    t0 = time.time()
    NotebookClient(nb, timeout=3600, kernel_name="python3", resources={"metadata": {"path": os.path.dirname(path)}}).execute()
    nbformat.write(nb, path)
    print(f"executed {n} in {time.time()-t0:.0f}s")
