"""Generates the five price-grid notebooks (run: python make_notebooks.py)."""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))

SETUP = r'''import os, sys, time
sys.path.insert(0, os.path.abspath(".."))          # repo root containing cheyette3f/
import numpy as np, pandas as pd, torch
import matplotlib.pyplot as plt
from cheyette3f import *

FAST = os.environ.get("CHEYETTE_FAST", "0") == "1"   # CHEYETTE_FAST=1 -> quick smoke-test grids
device = get_device()                                 # cuda if available, else cpu
print("device:", device_info(), "| FAST =", FAST)
os.makedirs("results", exist_ok=True)

# ---------------------------------------------------------------------------
# The model is FIXED here: calibrated parameters of the paper (Table 2),
# flat initial forward curve f(0,t) = 5%.  Edit to re-run on other parameters.
# ---------------------------------------------------------------------------
p = ModelParams()
print(p)

# sparse-grid PDE settings (paper-like refinement; FAST = coarse)
PDE = dict(level=2, ls=(2, 2, 0, 0), dt=1/48) if FAST else dict(level=3, ls=(3, 3, 0, 0), dt=1/96)
PDE.update(device=device, dtype=torch.float64)
print("PDE settings:", {k: v for k, v in PDE.items() if k != "device"})

def heatmap(df, title, fmt="{:.5f}", ax=None, cmap="viridis"):
    ax = ax or plt.gca()
    im = ax.imshow(df.values.astype(float), aspect="auto", cmap=cmap)
    ax.set_xticks(range(df.shape[1])); ax.set_xticklabels(df.columns)
    ax.set_yticks(range(df.shape[0])); ax.set_yticklabels(df.index)
    ax.set_xlabel(df.columns.name); ax.set_ylabel(df.index.name); ax.set_title(title)
    for i in range(df.shape[0]):
        for j in range(df.shape[1]):
            ax.text(j, i, fmt.format(df.values[i, j]), ha="center", va="center", color="w", fontsize=7)
    plt.colorbar(im, ax=ax)

def timed(fn, *a, **k):
    if device.type == "cuda": torch.cuda.synchronize()
    t0 = time.time(); out = fn(*a, **k)
    if device.type == "cuda": torch.cuda.synchronize()
    print(f"  elapsed {time.time()-t0:.1f}s")
    return out'''


def nb(cells, title):
    return {
        "cells": cells,
        "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python",
                                    "name": "python3"},
                     "language_info": {"name": "python"},
                     "title": title},
        "nbformat": 4, "nbformat_minor": 5,
    }


def md(s):
    return {"cell_type": "markdown", "metadata": {}, "source": s.strip("\n")}


def code(s):
    return {"cell_type": "code", "metadata": {}, "execution_count": None,
            "outputs": [], "source": s.strip("\n")}


# ============================================================================
# 1. Bonds
# ============================================================================
bonds = nb([
    md(r'''
# Zero-coupon bonds — PDE price grid over maturity

3 Factor Exponential Cheyette model (Beyna–Chiarella–Kang 2012), parameters fixed to the
paper's calibration. For each maturity $T$ the valuation PDE (Thm 7.3) with terminal
condition $g(T,x)=1$ is solved backward on the modified sparse grid (Appendix E) and
compared with the closed form $B(0,T)=e^{-f_0T}$ (paper Table 3).

Also shown: the analytic bond-price *surface* $B(t,T,x)$ of Theorem 4.1 as a function of the state.
'''),
    code(SETUP),
    md("## Contract grid (dimension: maturity $T$)"),
    code(r'''
Ts = [1.0, 2.0, 4.0] if FAST else [0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 10.0]
contracts = [Bond(T) for T in Ts]
analytic = price_analytic(p, contracts)
print("PDE pricing", len(contracts), "bonds (one solve per maturity) ...")
pde = timed(price_pde, p, contracts, **PDE)
df = pd.DataFrame({"T": Ts, "analytic": analytic, "pde": pde})
df["abs_err"] = np.abs(df.pde - df.analytic)
df["rel_err"] = df.abs_err / df.analytic
df.to_csv("results/bond_grid.csv", index=False)
df
'''),
    code(r'''
fig, ax = plt.subplots(1, 2, figsize=(11, 3.6))
ax[0].plot(df["T"], df.analytic, "k-", label="analytic"); ax[0].plot(df["T"], df.pde, "ro", label="sparse-grid PDE")
ax[0].set_xlabel("T"); ax[0].set_ylabel("B(0,T)"); ax[0].legend()
ax[1].semilogy(df["T"], df.abs_err, "o-"); ax[1].set_xlabel("T"); ax[1].set_ylabel("|PDE - analytic|"); ax[1].set_title("PDE error")
plt.tight_layout()
'''),
    md("## Analytic bond-price surface $B(t,T,x)$ (Theorem 4.1)"),
    code(r'''
t = 1.0
Tgrid = np.array([2.0, 3.0, 5.0, 10.0])
s = state_stds(p, t)                      # std of each state at t
shocks = np.array([-2, -1, 0, 1, 2])      # in units of std, applied to X1 (the c-driven state)
rows = []
for k in shocks:
    x = np.array([k * s[0], 0.0, 0.0, 0.0])
    rows.append([bond_price(p, t, T, x) for T in Tgrid])
surf = pd.DataFrame(rows, index=pd.Index(shocks, name="X1 shock (std)"), columns=pd.Index(Tgrid, name="T"))
surf.round(6)
'''),
], "bonds")

# ============================================================================
# 2. Caplets
# ============================================================================
caplets = nb([
    md(r'''
# Caplets — PDE price grid over (fixing date $T_C$, strike $K$)

Caplet on LIBOR $R(T_C,T_B)$, $T_B=T_C+\Delta$, notional 1. The PDE is solved from $T_C$ back
to 0 with terminal condition $\max(1-(1+K\Delta)B(T_C,T_B,x),0)$ (Theorem 7.4); all strikes with
the same $T_C$ are solved **in one batched GPU solve**. Reference: the closed form (eq. 20).
Errors are also reported in Black implied-volatility points, the paper's metric (Table 7).
'''),
    code(SETUP),
    md("## Contract grid (dimensions: $T_C$ × $K$; $\\Delta$ fixed)"),
    code(r'''
delta = 1.0
TCs = [1.0, 2.0] if FAST else [1.0, 2.0, 3.0, 4.0, 5.0]
Ks  = [0.04, 0.05, 0.06] if FAST else [0.03, 0.04, 0.05, 0.06, 0.07]
contracts = [Caplet(TC, TC + delta, K) for TC in TCs for K in Ks]
analytic = price_analytic(p, contracts)
print("PDE pricing", len(contracts), "caplets in", len(TCs), "batched solves ...")
pde = timed(price_pde, p, contracts, **PDE)
iv_pde, iv_an = caplet_implied_vols(p, contracts, pde), caplet_implied_vols(p, contracts, analytic)
df = pd.DataFrame({"TC": [c.TC for c in contracts], "TB": [c.TB for c in contracts], "K": [c.K for c in contracts],
                   "analytic": analytic, "pde": pde, "abs_err": np.abs(pde - analytic),
                   "iv_analytic": iv_an, "iv_pde": iv_pde, "iv_err_pts": 100 * (iv_pde - iv_an)})
df.to_csv("results/caplet_grid.csv", index=False)
df.round(7)
'''),
    code(r'''
price_grid = df.pivot(index="TC", columns="K", values="pde")
err_grid   = df.pivot(index="TC", columns="K", values="iv_err_pts")
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
heatmap(price_grid, "caplet price (PDE)", ax=ax[0])
heatmap(err_grid, "implied-vol error vs closed form (vol points)", fmt="{:+.3f}", ax=ax[1], cmap="coolwarm")
plt.tight_layout()
'''),
    md("### ATM check against the paper (Table 5, $K=5\\%$)"),
    code(r'''
paper = {1.0: 0.004183, 2.0: 0.005318, 3.0: 0.006077, 4.0: 0.006792, 5.0: 0.007788}
atm = df[np.isclose(df.K, 0.05)][["TC", "analytic", "pde"]].copy()
atm["paper_table5"] = atm["TC"].map(paper)
atm.round(6)
'''),
], "caplets")

# ============================================================================
# 3. Vanilla swaps
# ============================================================================
swaps = nb([
    md(r'''
# Vanilla swaps — analytic pricer and PDE grid over (start $T_0$, length $T_N$, fixed rate $K$)

`Swap(T0, TN, K, tenor, notional, payer)` is the vanilla swap pricer: payments at
$T_0+\text{tenor},\dots,T_0+T_N$, floating leg $B(t,T_0)-B(t,T_0+T_N)$ (single curve), value /
par rate / annuity / DV01 from the analytic bond formula at any $(t,x)$.

For forward-starting swaps ($T_0>0$) the same value is recovered by the PDE with terminal condition
$V_{\text{swap}}(T_0,x)$ — a linearity check of the solver (the payoff is a sum of exponentials in $x$).
'''),
    code(SETUP),
    md("## Contract grid (dimensions: $T_0$ × $T_N$ × $K$)"),
    code(r'''
T0s = [0.0, 1.0] if FAST else [0.0, 1.0, 2.0, 3.0]
TNs = [1.0, 3.0, 5.0] if FAST else [1.0, 2.0, 3.0, 5.0, 7.0, 10.0]
Ks  = [0.03, 0.05, 0.07]
contracts = [Swap(T0, TN, K) for T0 in T0s for TN in TNs for K in Ks]
rows = []
for c in contracts:
    rows.append(dict(T0=c.T0, TN=c.TN, K=c.K, value=c.value(p), par_rate=c.par_rate(p),
                     annuity=c.annuity(p), float_leg=c.float_leg(p), dv01=c.dv01(p)))
df = pd.DataFrame(rows)
print("PDE pricing", len(contracts), "swaps in", len([t for t in T0s if t > 0]), "batched solves (spot swaps need no PDE) ...")
df["pde"] = timed(price_pde, p, contracts, **PDE)
df["abs_err"] = np.abs(df.pde - df.value)
df.to_csv("results/swap_grid.csv", index=False)
df.round(7)
'''),
    code(r'''
par = df[df.K == 0.05].pivot(index="T0", columns="TN", values="par_rate")
val = df[df.K == 0.05].pivot(index="T0", columns="TN", values="value")
fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
heatmap(100 * par, "forward par swap rate (%)", fmt="{:.3f}", ax=ax[0])
heatmap(val, "payer swap value, K = 5%", ax=ax[1], cmap="coolwarm")
plt.tight_layout()
'''),
    md("## Swap value as a function of the state (mark-to-market at a future date)"),
    code(r'''
c = Swap(2.0, 5.0, 0.05)
t = 1.0
s = state_stds(p, t)
xs = np.linspace(-3, 3, 13)
mtm = pd.DataFrame({"X1 shock (std)": xs,
                    "value": [c.value(p, t, np.array([k * s[0], 0, 0, 0])) for k in xs],
                    "par_rate": [c.par_rate(p, t, np.array([k * s[0], 0, 0, 0])) for k in xs]})
mtm.round(6)
'''),
], "swaps")

# ============================================================================
# 4. European swaptions
# ============================================================================
swaptions = nb([
    md(r'''
# European payer swaptions — PDE price grid over ($T_0$, $T_N$, $K$)

Right at $T_0$ to enter `Swap(T0, TN, K)` (paper convention: payments at $T_0+1,\dots,T_0+T_N$).
All ($T_N$, $K$) with the same expiry share one batched sparse-grid solve. Reference values come
from the exact-distribution scrambled-Sobol QMC pricer on the GPU (Section 6 of the paper),
and the paper's Table 10 values are shown for comparison.
'''),
    code(SETUP),
    md("## Contract grid (dimensions: $T_0$ × $T_N$ × $K$)"),
    code(r'''
T0s = [1.0] if FAST else [1.0, 2.0, 3.0]
TNs = [1.0, 3.0] if FAST else [1.0, 2.0, 3.0, 5.0]
Ks  = [0.03, 0.05, 0.07] if FAST else [0.03, 0.04, 0.05, 0.06, 0.07]
contracts = [Swaption(T0, TN, K) for T0 in T0s for TN in TNs for K in Ks]
print("PDE pricing", len(contracts), "swaptions in", len(T0s), "batched solves ...")
pde = timed(price_pde, p, contracts, **PDE)
print("QMC reference (2^18 Sobol points per expiry) ...")
qmc, _ = timed(price_mc, p, contracts, n=1 << 18, qmc=True, device=device)
df = pd.DataFrame({"T0": [c.T0 for c in contracts], "TN": [c.TN for c in contracts], "K": [c.K for c in contracts],
                   "pde": pde, "qmc": qmc})
df["diff"] = df.pde - df.qmc
df.to_csv("results/eur_swaption_grid.csv", index=False)
df.round(7)
'''),
    code(r'''
fig, axes = plt.subplots(len(T0s), 2, figsize=(12, 3.8 * len(T0s)), squeeze=False)
for i, T0 in enumerate(T0s):
    sub = df[df.T0 == T0]
    heatmap(sub.pivot(index="TN", columns="K", values="pde"), f"swaption price (PDE), T0 = {T0}", ax=axes[i, 0])
    heatmap(sub.pivot(index="TN", columns="K", values="diff"), f"PDE - QMC, T0 = {T0}", fmt="{:+.5f}", ax=axes[i, 1], cmap="coolwarm")
plt.tight_layout()
'''),
    md("### Comparison with the paper (Table 10: T0=1, TN=3)"),
    code(r'''
paper = {0.03: (0.054195, 0.054157), 0.05: (0.011791, 0.011237), 0.07: (0.000351, 0.000262)}   # (PDE, MC)
sub = df[(df.T0 == 1.0) & (df.TN == 3.0) & df.K.isin(paper)].copy()
sub["paper_pde"] = sub.K.map(lambda k: paper[k][0]); sub["paper_mc"] = sub.K.map(lambda k: paper[k][1])
sub.round(6)
'''),
], "eur_swaptions")

# ============================================================================
# 5. Bermudan swaptions
# ============================================================================
bermudans = nb([
    md(r'''
# Bermudan payer swaptions — PDE price grid over ($T_0$, $T_N$, $K$)

Exercise dates every 6 months up to and including $T_0$. Two exercise conventions are priced:

* **sliding** (default): exercising at $t$ enters a $T_N$-year swap starting at $t$;
* **same forward swap**: every exercise enters the swap starting at $T_0$ (the paper's wording).
  Its deflated value is a $Q^{T_0}$-martingale, so the early-exercise premium is provably zero —
  a useful consistency check of the solver.

The early-exercise premium is reported against the European swaption priced with the same grid.
Exercise is applied as $g\leftarrow\max(g,\text{exercise value})$ at the exercise dates.
'''),
    code(SETUP),
    md("## Contract grid (dimensions: $T_0$ × $T_N$ × $K$)"),
    code(r'''
T0s = [1.0] if FAST else [1.0, 2.0]
TNs = [1.0, 3.0] if FAST else [1.0, 3.0, 5.0]
Ks  = [0.03, 0.05, 0.07] if FAST else [0.03, 0.04, 0.05, 0.06, 0.07]
def ex_dates(T0): return tuple(float(v) for v in np.round(np.arange(0.5, T0 - 1e-9, 0.5), 6))
sliding = [BermudanSwaption(T0, TN, K, ex_dates(T0), sliding=True) for T0 in T0s for TN in TNs for K in Ks]
same    = [BermudanSwaption(T0, TN, K, ex_dates(T0), sliding=False) for T0 in T0s for TN in TNs for K in Ks]
european = [Swaption(T0, TN, K) for T0 in T0s for TN in TNs for K in Ks]
print("PDE pricing", len(sliding), "x 3 contracts in", 3 * len(T0s), "batched solves ...")
v_sl  = timed(price_pde, p, sliding, **PDE)
v_sm  = timed(price_pde, p, same, **PDE)
v_eur = timed(price_pde, p, european, **PDE)
df = pd.DataFrame({"T0": [c.T0 for c in sliding], "TN": [c.TN for c in sliding], "K": [c.K for c in sliding],
                   "exercise_dates": [str(c.exercise_dates + (c.T0,)) for c in sliding],
                   "european": v_eur, "bermudan_sliding": v_sl, "bermudan_same_swap": v_sm})
df["premium_sliding"] = df.bermudan_sliding - df.european
df["premium_same_swap"] = df.bermudan_same_swap - df.european
df.to_csv("results/bermudan_swaption_grid.csv", index=False)
df.round(7)
'''),
    code(r'''
fig, axes = plt.subplots(len(T0s), 2, figsize=(12, 3.8 * len(T0s)), squeeze=False)
for i, T0 in enumerate(T0s):
    sub = df[df.T0 == T0]
    heatmap(sub.pivot(index="TN", columns="K", values="bermudan_sliding"), f"Bermudan (sliding) price, T0 = {T0}", ax=axes[i, 0])
    heatmap(sub.pivot(index="TN", columns="K", values="premium_sliding"), f"early-exercise premium, T0 = {T0}", fmt="{:+.5f}", ax=axes[i, 1], cmap="coolwarm")
plt.tight_layout()
'''),
    md("### Comparison with the paper (Table 11: T0=1, TN=3, TEx=0.5)"),
    code(r'''
paper = {0.03: (0.058531, 0.059184), 0.05: (0.012930, 0.014581), 0.07: (0.001308, 0.001360)}   # (PDE, MC)
sub = df[(df.T0 == 1.0) & (df.TN == 3.0) & df.K.isin(paper)].copy()
sub["paper_pde"] = sub.K.map(lambda k: paper[k][0]); sub["paper_mc"] = sub.K.map(lambda k: paper[k][1])
sub[["K", "european", "bermudan_sliding", "bermudan_same_swap", "paper_pde", "paper_mc"]].round(6)
# NB: the paper's Bermudan premia (Table 12) are positive under a definition for which the premium is
# provably zero; its own Bermudan PDE and MC disagree by up to 1.65e-3 and the K=7% Bermudan is ~3x the
# European.  Treat those reference numbers as indicative only.
'''),
], "bermudan_swaptions")

for name, book in [("01_bonds", bonds), ("02_caplets", caplets), ("03_vanilla_swaps", swaps),
                   ("04_european_swaptions", swaptions), ("05_bermudan_swaptions", bermudans)]:
    with open(os.path.join(HERE, name + ".ipynb"), "w") as fh:
        json.dump(book, fh, indent=1)
    print("wrote", name + ".ipynb")
