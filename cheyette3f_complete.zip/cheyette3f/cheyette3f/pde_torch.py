"""
CUDA (PyTorch) implementation of the sparse-grid PDE solver of Section 7 /
Appendix E, designed for GPUs.

Design
------
* **matrix-free**: the 4-D PDE operator (Theorem 7.3) is applied to a tensor
  g(x1,x2,x3,x4) with slicing stencils -- no sparse matrices, no LU
  factorizations, everything is an elementwise kernel.
* **batched over contracts**: the operator does not depend on the contract,
  only the terminal condition (and exercise values) do.  All contracts with
  the same PDE horizon T (and exercise schedule) are solved *simultaneously*
  along a leading batch dimension.  A grid of prices over strikes / tenors is
  therefore essentially free on a GPU compared with a single price.
* **implicit steps by batched, Jacobi-preconditioned BiCGSTAB**.  The
  theta-scheme matrix I - theta*dt*A is a small perturbation of the identity
  (diffusion numbers sigma^2 dt / h^2 << 1 on these grids), so a handful of
  iterations reaches 1e-10.
* float64 by default (float32 possible on consumer GPUs), device selectable,
  optional torch.compile of the operator (fuses the stencil kernels).

The discretisation is the same as in `pde.py` (central differences, one-sided
first derivatives at the ends, linearity boundary condition g'' = 0,
Rannacher start-up + Crank-Nicolson, modified sparse-grid combination) and
both solvers agree to the BiCGSTAB tolerance.
"""
from __future__ import annotations

from itertools import product
from math import comb
import numpy as np
import torch

from .model import ModelParams, V11, V12, V22, V2_11, V3_11
from .montecarlo import state_stds


# ----------------------------------------------------------------------------
# device helpers
# ----------------------------------------------------------------------------
def get_device(device=None) -> torch.device:
    if device is None:
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device)


def device_info() -> str:
    if torch.cuda.is_available():
        i = torch.cuda.current_device()
        return f"cuda:{i} ({torch.cuda.get_device_name(i)})"
    return f"cpu ({torch.get_num_threads()} threads)"


# ----------------------------------------------------------------------------
# tensor grid
# ----------------------------------------------------------------------------
class Grid:
    """Symmetric uniform tensor grid with 2^levels[j]+1 points per dimension.

    coords[j] is the 1-D coordinate vector of dimension j reshaped to
    broadcast against batched solution tensors of shape (B, n1, n2, n3, n4).
    """

    def __init__(self, levels, halfwidths, device, dtype):
        self.levels = tuple(int(l) for l in levels)
        self.ns = tuple(2 ** l + 1 for l in self.levels)
        self.device, self.dtype = device, dtype
        self.xs = [torch.linspace(-float(R), float(R), n, device=device,
                                  dtype=dtype)
                   for n, R in zip(self.ns, halfwidths)]
        self.hs = [float(2.0 * R / (n - 1)) for n, R in zip(self.ns, halfwidths)]
        self.coords = [x.reshape([1] + [n if k == j else 1
                                        for k, n in enumerate(self.ns)])
                       for j, x in enumerate(self.xs)]
        self.xsum = self.coords[0] + self.coords[1] + self.coords[2] + self.coords[3]
        self.N = int(np.prod(self.ns))

    # diagonal entries of the 1-D stencils (for the Jacobi preconditioner)
    def d1_diag(self, j):
        n, h = self.ns[j], self.hs[j]
        d = torch.zeros(n, device=self.device, dtype=self.dtype)
        if n > 1:
            d[0], d[-1] = -1.0 / h, 1.0 / h
        return d.reshape(self.coords[j].shape)

    def d2_diag(self, j):
        n, h = self.ns[j], self.hs[j]
        d = torch.zeros(n, device=self.device, dtype=self.dtype)
        if n > 2:
            d[1:-1] = -2.0 / h ** 2
        return d.reshape(self.coords[j].shape)


def _sl(ax, a, b):
    """Slice along tensor axis ax+1 (axis 0 is the batch)."""
    return (slice(None),) * (ax + 1) + (slice(a, b),)


def d1(u: torch.Tensor, ax: int, h: float) -> torch.Tensor:
    """First derivative along grid dimension ax (central, one-sided ends)."""
    n = u.shape[ax + 1]
    out = torch.empty_like(u)
    if n == 1:
        return out.zero_()
    out[_sl(ax, 1, -1)] = (u[_sl(ax, 2, None)] - u[_sl(ax, None, -2)]) * (0.5 / h)
    out[_sl(ax, 0, 1)] = (u[_sl(ax, 1, 2)] - u[_sl(ax, 0, 1)]) * (1.0 / h)
    out[_sl(ax, -1, None)] = (u[_sl(ax, -1, None)] - u[_sl(ax, -2, -1)]) * (1.0 / h)
    return out


def d2(u: torch.Tensor, ax: int, h: float) -> torch.Tensor:
    """Second derivative along dimension ax, zero at the ends (g'' = 0 BC)."""
    n = u.shape[ax + 1]
    out = torch.zeros_like(u)
    if n > 2:
        out[_sl(ax, 1, -1)] = (u[_sl(ax, 2, None)] - 2.0 * u[_sl(ax, 1, -1)]
                               + u[_sl(ax, None, -2)]) * (1.0 / h ** 2)
    return out


# ----------------------------------------------------------------------------
# the PDE operator A(t)
# ----------------------------------------------------------------------------
class Operator:
    """A(t) g = sum_j b_j(t,x) g_j + 1/2 sum_ij [ss^T]_ij(t) g_ij - r(x) g."""

    def __init__(self, p: ModelParams, grid: Grid, compile: bool = False):
        self.p, self.g = p, grid
        self.r = p.f0 + grid.xsum                          # (1,n1,n2,n3,n4)
        lams = p.state_lams
        # state-dependent drift parts -lam_j x_j (X1 has none)
        self.mr = [None] + [-float(lams[j]) * grid.coords[j] for j in (1, 2, 3)]
        self.d1diag = [grid.d1_diag(j) for j in range(4)]
        self.d2diag = [grid.d2_diag(j) for j in range(4)]
        self._apply = self._apply_impl
        if compile:
            try:
                self._apply = torch.compile(self._apply_impl, dynamic=True)
            except Exception:  # pragma: no cover
                self._apply = self._apply_impl

    def coefs(self, t: float):
        p = self.p
        b2, b3, b4 = float(p.beta(1, t)), float(p.beta(2, t)), float(p.beta(3, t))
        drift = (float(V11(p, t) + V12(p, t)), float(V12(p, t) + V22(p, t)),
                 float(V2_11(p, t)), float(V3_11(p, t)))
        diff = (0.5 * p.c ** 2, 0.5 * b2 ** 2, 0.5 * b3 ** 2, 0.5 * b4 ** 2)
        mix = p.c * b2
        return drift, diff, mix

    def _apply_impl(self, u, drift, diff, mix):
        g = self.g
        out = -self.r * u
        du0 = None
        for j in range(4):
            du = d1(u, j, g.hs[j])
            if j == 0:
                du0 = du
                out = out + drift[0] * du
            else:
                out = out + (drift[j] + self.mr[j]) * du
            out = out + diff[j] * d2(u, j, g.hs[j])
        out = out + mix * d1(du0, 1, g.hs[1])
        return out

    def apply(self, u: torch.Tensor, t: float) -> torch.Tensor:
        drift, diff, mix = self.coefs(t)
        return self._apply(u, drift, diff, mix)

    def diagonal(self, t: float) -> torch.Tensor:
        """diag(A(t)) as a broadcastable tensor (Jacobi preconditioner)."""
        drift, diff, mix = self.coefs(t)
        d = -self.r
        for j in range(4):
            dr = drift[j] if j == 0 else drift[j] + self.mr[j]
            d = d + dr * self.d1diag[j] + diff[j] * self.d2diag[j]
        d = d + mix * self.d1diag[0] * self.d1diag[1]
        return d


# ----------------------------------------------------------------------------
# batched BiCGSTAB
# ----------------------------------------------------------------------------
def _bdot(a, b):
    """Per-batch inner product, shape (B,1,1,1,1)."""
    return (a * b).sum(dim=(1, 2, 3, 4), keepdim=True)


def _sdiv(a, b):
    return a / torch.where(b == 0, torch.ones_like(b), b)


def bicgstab(Aop, b, Minv, x0, tol=1e-10, maxit=300):
    """Right-preconditioned BiCGSTAB, batched along dim 0.

    Solves A x = b for every batch element with the same operator.  Returns
    (x, iterations, converged_flag).
    """
    x = x0.clone()
    r = b - Aop(x)
    rhat = r.clone()
    bnorm = torch.sqrt(_bdot(b, b))
    tol_b = tol * torch.clamp(bnorm, min=1e-300)
    rnorm = torch.sqrt(_bdot(r, r))
    if bool((rnorm <= tol_b).all()):
        return x, 0, True
    rho_old = torch.ones_like(bnorm)
    alpha = torch.ones_like(bnorm)
    omega = torch.ones_like(bnorm)
    v = torch.zeros_like(r)
    p = torch.zeros_like(r)
    for it in range(1, maxit + 1):
        rho = _bdot(rhat, r)
        beta = _sdiv(rho, rho_old) * _sdiv(alpha, omega)
        p = r + beta * (p - omega * v)
        y = Minv * p
        v = Aop(y)
        alpha = _sdiv(rho, _bdot(rhat, v))
        s = r - alpha * v
        z = Minv * s
        tt = Aop(z)
        omega = _sdiv(_bdot(tt, s), _bdot(tt, tt))
        x = x + alpha * y + omega * z
        r = s - omega * tt
        rho_old = rho
        rnorm = torch.sqrt(_bdot(r, r))
        if bool((rnorm <= tol_b).all()):
            return x, it, True
    return x, maxit, False


# ----------------------------------------------------------------------------
# single-grid solver
# ----------------------------------------------------------------------------
def solve_on_grid_t(p: ModelParams, levels, halfwidths, T: float, payoff_fn,
                    dt: float, theta: float = 0.5, rannacher: int = 4,
                    exercise_dates=None, exercise_fn=None, eval_point=None,
                    device=None, dtype=torch.float64, tol: float = 1e-10,
                    compile: bool = False, stats: dict | None = None):
    """Solve the valuation PDE backward on one tensor grid for a *batch* of
    contracts.  payoff_fn(grid) -> tensor (B, n1, n2, n3, n4);
    exercise_fn(t, grid) -> tensor of the same shape.  Returns (B,) prices
    at eval_point (default: today's state x = 0)."""
    device = get_device(device)
    grid = Grid(levels, halfwidths, device, dtype)
    op = Operator(p, grid, compile=compile)

    g = payoff_fn(grid).to(dtype)
    if g.dim() == 4:
        g = g.unsqueeze(0)
    n_steps = int(round(T / dt))
    ex = sorted(exercise_dates or [])
    iters = 0
    for m in range(n_steps):
        t_old = T - m * dt
        t_new = T - (m + 1) * dt
        th = 1.0 if m < rannacher else theta
        if th < 1.0:
            rhs = g + ((1.0 - th) * dt) * op.apply(g, t_old)
        else:
            rhs = g
        Minv = 1.0 / (1.0 - th * dt * op.diagonal(t_new))
        Aop = lambda v, tn=t_new, th=th: v - (th * dt) * op.apply(v, tn)
        g, it, ok = bicgstab(Aop, rhs, Minv, g, tol=tol)
        iters += it
        if not ok:
            import warnings
            warnings.warn(f"BiCGSTAB did not converge at t={t_new:.4f}")
        for te in ex:
            if abs(t_new - te) < 0.5 * dt:
                g = torch.maximum(g, exercise_fn(te, grid).to(dtype))
    if stats is not None:
        stats["iters"] = stats.get("iters", 0) + iters
        stats["steps"] = stats.get("steps", 0) + n_steps
    return interp_t(grid, g, eval_point)


def interp_t(grid: Grid, g: torch.Tensor, pt=None) -> torch.Tensor:
    """Multilinear interpolation of the batched tensor at a point (B,)."""
    pt = np.zeros(4) if pt is None else np.asarray(pt, dtype=float)
    ws = []
    for x, q in zip(grid.xs, pt):
        n = len(x)
        w = torch.zeros(n, device=g.device, dtype=g.dtype)
        if n == 1:
            w[0] = 1.0
        else:
            xn = x.detach().cpu().numpy()
            i = int(np.clip(np.searchsorted(xn, q) - 1, 0, n - 2))
            a = (q - xn[i]) / (xn[i + 1] - xn[i])
            w[i], w[i + 1] = 1.0 - a, a
        ws.append(w)
    return torch.einsum("bijkl,i,j,k,l->b", g, *ws)


# ----------------------------------------------------------------------------
# modified sparse-grid combination technique (Appendix E.2.2)
# ----------------------------------------------------------------------------
def _compositions(total: int, parts: int):
    if parts == 1:
        yield (total,)
        return
    for i in range(total + 1):
        for rest in _compositions(total - i, parts - 1):
            yield (i,) + rest


def combination_grids(level: int, ls=(3, 3, 0, 0)):
    """(levels, coefficient) pairs of the d=4 combination formula
    u = sum_{q=0}^{3} (-1)^q C(3,q) sum_{|i|_1 = level-q} u_{i+ls}."""
    out = []
    for q in range(4):
        lv = level - q
        if lv < 0:
            continue
        coef = (-1) ** q * comb(3, q)
        for compo in _compositions(lv, 4):
            out.append((tuple(c + l0 for c, l0 in zip(compo, ls)), coef))
    return out


def combination_price_t(p: ModelParams, T: float, payoff_fn, level: int = 3,
                        ls=(3, 3, 0, 0), dt: float = 1.0 / 96,
                        halfwidths=None, width_mult: float = 6.0,
                        exercise_dates=None, exercise_fn=None,
                        device=None, dtype=torch.float64, tol: float = 1e-10,
                        compile: bool = False, verbose: bool = False,
                        stats: dict | None = None) -> np.ndarray:
    """Batched sparse-grid price(s): returns a numpy array of shape (B,)."""
    if halfwidths is None:
        s = state_stds(p, T)
        halfwidths = width_mult * np.maximum(s, 1e-6)
    total = None
    for levels, coef in combination_grids(level, ls):
        v = solve_on_grid_t(p, levels, halfwidths, T, payoff_fn, dt,
                            exercise_dates=exercise_dates,
                            exercise_fn=exercise_fn, device=device,
                            dtype=dtype, tol=tol, compile=compile, stats=stats)
        total = coef * v if total is None else total + coef * v
        if verbose:
            print(f"  grid {levels}: coef {coef:+d}  "
                  f"first value {float(v[0]):.8f}")
    return total.detach().cpu().numpy()
