"""
Contract definitions and a pricing façade.

Each contract knows
  * its PDE horizon (the time at which the terminal condition is applied),
  * how to build its (batched) terminal / exercise values on a torch Grid,
  * where available, its analytic time-0 price.

`price_pde` groups contracts by (horizon, exercise schedule) and prices each
group in ONE batched sparse-grid solve on the GPU; `price_analytic` and
`price_mc` give the reference values.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence
import numpy as np
import torch

from .model import (ModelParams, G_vec, H_func, disc0, bond_price,
                    caplet_analytic, swap_value, implied_vol)
from .pde_torch import Grid, combination_price_t, get_device


# ----------------------------------------------------------------------------
# torch versions of the analytic building blocks (evaluated on a Grid)
# ----------------------------------------------------------------------------
def bond_price_grid(p: ModelParams, t: float, T: float, grid: Grid):
    """B(t,T,x) on the grid, shape (1,n1,n2,n3,n4) (eq. 13)."""
    g = G_vec(p, t, T)
    z = sum(float(g[j]) * grid.coords[j] for j in range(4))
    scale = float(disc0(p, T) / disc0(p, t)) * float(np.exp(-H_func(p, t, T)))
    return scale * torch.exp(-z)


def swap_value_grid(p: ModelParams, t: float, grid: Grid, T0: float,
                    TN: float, K: float, tenor: float = 1.0,
                    notional: float = 1.0, payer: bool = True):
    """Value at t of a swap starting at T0, length TN, fixed rate K (the
    paper's convention: payments at T0+tenor, ..., T0+TN)."""
    n = int(round(TN / tenor))
    pays = T0 + tenor * np.arange(1, n + 1)
    ann = None
    for Ti in pays:
        b = tenor * bond_price_grid(p, t, float(Ti), grid)
        ann = b if ann is None else ann + b
    v = (bond_price_grid(p, t, T0, grid) - bond_price_grid(p, t, float(pays[-1]), grid)
         - K * ann)
    return notional * (v if payer else -v)


# ----------------------------------------------------------------------------
# contracts
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class Bond:
    """Zero-coupon bond paying 1 at T."""
    T: float

    @property
    def horizon(self):
        return self.T

    @property
    def group_key(self):
        return ("bond", round(self.T, 10))

    def payoff(self, p, grid):
        return torch.ones((1,) + grid.ns, device=grid.device, dtype=grid.dtype)

    def analytic(self, p):
        return float(disc0(p, self.T))


@dataclass(frozen=True)
class Caplet:
    """Caplet on LIBOR R(TC,TB) with strike K, paid at TB, notional 1."""
    TC: float
    TB: float
    K: float

    @property
    def horizon(self):
        return self.TC

    @property
    def group_key(self):
        return ("caplet", round(self.TC, 10))

    def payoff(self, p, grid):
        B = bond_price_grid(p, self.TC, self.TB, grid)
        return torch.clamp(1.0 - (1.0 + self.K * (self.TB - self.TC)) * B, min=0.0)

    def analytic(self, p):
        return float(caplet_analytic(p, self.TC, self.TB, self.K))


@dataclass(frozen=True)
class Swap:
    """Vanilla fixed-for-floating swap.

    T0: start (first fixing), TN: length in years (payments at
    T0+tenor, ..., T0+TN), K: fixed rate, payer=True receives floating.
    """
    T0: float
    TN: float
    K: float
    tenor: float = 1.0
    notional: float = 1.0
    payer: bool = True

    @property
    def horizon(self):
        return self.T0

    @property
    def group_key(self):
        return ("swap", round(self.T0, 10))

    def payoff(self, p, grid):
        return swap_value_grid(p, self.T0, grid, self.T0, self.TN, self.K,
                               self.tenor, self.notional, self.payer)

    # ---- analytics ---------------------------------------------------------
    def payment_dates(self):
        n = int(round(self.TN / self.tenor))
        return self.T0 + self.tenor * np.arange(1, n + 1)

    def annuity(self, p, t=0.0, x=None):
        x = np.zeros(4) if x is None else np.asarray(x, float)
        return float(sum(self.tenor * bond_price(p, t, Ti, x)
                         for Ti in self.payment_dates()))

    def float_leg(self, p, t=0.0, x=None):
        x = np.zeros(4) if x is None else np.asarray(x, float)
        return float(bond_price(p, t, self.T0, x)
                     - bond_price(p, t, self.payment_dates()[-1], x))

    def par_rate(self, p, t=0.0, x=None):
        return self.float_leg(p, t, x) / self.annuity(p, t, x)

    def value(self, p, t=0.0, x=None):
        v = self.float_leg(p, t, x) - self.K * self.annuity(p, t, x)
        return self.notional * (v if self.payer else -v)

    def dv01(self, p, t=0.0, x=None):
        """Value change for a +1bp move in the fixed rate K."""
        return (-1.0 if self.payer else 1.0) * 1e-4 * self.notional * self.annuity(p, t, x)

    def analytic(self, p):
        return self.value(p)


@dataclass(frozen=True)
class Swaption:
    """European payer swaption: right at T0 to enter Swap(T0, TN, K)."""
    T0: float
    TN: float
    K: float
    tenor: float = 1.0
    notional: float = 1.0
    payer: bool = True

    @property
    def horizon(self):
        return self.T0

    @property
    def group_key(self):
        return ("swaption", round(self.T0, 10))

    def payoff(self, p, grid):
        v = swap_value_grid(p, self.T0, grid, self.T0, self.TN, self.K,
                            self.tenor, self.notional, self.payer)
        return torch.clamp(v, min=0.0)

    def underlying(self):
        return Swap(self.T0, self.TN, self.K, self.tenor, self.notional, self.payer)


@dataclass(frozen=True)
class BermudanSwaption:
    """Bermudan payer swaption with exercise dates < T0 plus T0.

    sliding=False: every exercise enters the *same* forward swap starting at
    T0 (the paper's wording; early-exercise premium is exactly 0).
    sliding=True : exercise at t enters a TN-year swap starting at t.
    """
    T0: float
    TN: float
    K: float
    exercise_dates: tuple = ()
    sliding: bool = True
    tenor: float = 1.0
    notional: float = 1.0
    payer: bool = True

    @property
    def horizon(self):
        return self.T0

    @property
    def group_key(self):
        return ("bermudan", round(self.T0, 10),
                tuple(round(float(e), 10) for e in self.exercise_dates),
                self.sliding)

    def payoff(self, p, grid):
        v = swap_value_grid(p, self.T0, grid, self.T0, self.TN, self.K,
                            self.tenor, self.notional, self.payer)
        return torch.clamp(v, min=0.0)

    def exercise(self, p, t, grid):
        start = t if self.sliding else self.T0
        v = swap_value_grid(p, t, grid, start, self.TN, self.K, self.tenor,
                            self.notional, self.payer)
        return torch.clamp(v, min=0.0)


# ----------------------------------------------------------------------------
# pricing façade
# ----------------------------------------------------------------------------
def price_analytic(p: ModelParams, contracts: Sequence) -> np.ndarray:
    out = []
    for c in contracts:
        if not hasattr(c, "analytic"):
            raise ValueError(f"{type(c).__name__} has no closed form")
        out.append(c.analytic(p))
    return np.array(out)


def price_pde(p: ModelParams, contracts: Sequence, level: int = 3,
              ls=(3, 3, 0, 0), dt: float = 1.0 / 96, width_mult: float = 6.0,
              device=None, dtype=torch.float64, tol: float = 1e-10,
              compile: bool = False, verbose: bool = False,
              stats: dict | None = None) -> np.ndarray:
    """Price a list of contracts with the batched GPU sparse-grid PDE solver.

    Contracts are grouped by PDE horizon / exercise schedule; each group is a
    single batched solve.  Returns prices in input order.
    """
    device = get_device(device)
    contracts = list(contracts)
    groups: dict = {}
    for i, c in enumerate(contracts):
        groups.setdefault(c.group_key, []).append(i)
    prices = np.full(len(contracts), np.nan)
    for key, idx in groups.items():
        cs = [contracts[i] for i in idx]
        T = cs[0].horizon
        if T <= 0.0:                      # spot contracts: no PDE needed
            prices[idx] = [c.analytic(p) for c in cs]
            continue

        def payoff_fn(grid, cs=cs):
            return torch.cat([c.payoff(p, grid) for c in cs], dim=0)

        ex_dates, ex_fn = None, None
        if hasattr(cs[0], "exercise"):
            ex_dates = list(cs[0].exercise_dates)

            def ex_fn(t, grid, cs=cs):
                return torch.cat([c.exercise(p, t, grid) for c in cs], dim=0)

        if verbose:
            print(f"group {key}: {len(cs)} contracts, horizon {T}")
        v = combination_price_t(p, T, payoff_fn, level=level, ls=ls, dt=dt,
                                width_mult=width_mult, exercise_dates=ex_dates,
                                exercise_fn=ex_fn, device=device, dtype=dtype,
                                tol=tol, compile=compile, stats=stats)
        prices[idx] = v
    return prices


def caplet_implied_vols(p: ModelParams, caplets: Sequence[Caplet],
                        prices) -> np.ndarray:
    return np.array([implied_vol(p, c.TC, c.TB, c.K, v)
                     for c, v in zip(caplets, prices)])
