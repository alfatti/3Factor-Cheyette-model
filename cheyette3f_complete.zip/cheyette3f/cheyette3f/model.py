"""
Core model for Beyna, Chiarella & Kang (2012):
"Pricing Interest Rate Derivatives in a Multifactor HJM Model with
Time Dependent Volatility" (UTS QFRC Research Paper 317).

The 3 Factor Exponential (Cheyette / Markovian Gaussian HJM) model with
forward-rate volatility

    sigma_1(t,T) = c + (a0_1 + a1_1 t) exp(-lam1 (T-t))      (eq. 9)
    sigma_2(t,T) =     (a0_2 + a1_2 t) exp(-lam2 (T-t))      (eq. 10)
    sigma_3(t,T) =     (a0_3 + a1_3 t) exp(-lam3 (T-t))      (eq. 11)

is driven by four Markov state variables

    X1 = X^{(1)}_1  (alpha = 1,            beta = c)
    X2 = X^{(1)}_2  (alpha = e^{-lam1 t},  beta = a0_1 + a1_1 t)
    X3 = X^{(2)}_1  (alpha = e^{-lam2 t},  beta = a0_2 + a1_2 t)
    X4 = X^{(3)}_1  (alpha = e^{-lam3 t},  beta = a0_3 + a1_3 t)

with short rate r(t) = f(0,t) + X1 + X2 + X3 + X4.

This module implements:
  * the calibrated parameters (Table 2),
  * the deterministic V^{(k)}_{ij}(t) functions (Appendix A.1, eq. 5),
  * the analytic zero-coupon bond price (Theorem 4.1 / Lemma 4.2, eqs 12-13),
  * bond price volatilities b_k(t,T) (Section 4.2.1, eq. 18),
  * the analytic caplet formula (eq. 20) with v^2 computed by quadrature
    (equivalent to the closed forms U_k of Appendix A.2),
  * swap values / (European) swaption payoffs from the analytic bond formula,
  * Black implied volatility (used by the paper as its error metric).
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.stats import norm


# ----------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class ModelParams:
    """Calibrated parameters (paper, Table 2, data of 30/4/2010).

    Note the calibrated mean-reversion parameters lam_k are *negative*
    (volatility growing in time-to-maturity); all formulas remain valid.
    """
    # factor 1 : sigma_1 = c + (a0_1 + a1_1 t) exp(-lam1 (T - t))
    c: float = 0.0097
    a1_1: float = -0.0005
    a0_1: float = -0.000165
    lam1: float = -0.004
    # factor 2
    a1_2: float = 0.000021
    a0_2: float = -0.000742
    lam2: float = -0.430
    # factor 3
    a1_3: float = 0.0000193
    a0_3: float = 0.000701
    lam3: float = -0.51
    # flat initial forward curve f(0,T) = f0 (Section 8, Theorem 7.4)
    f0: float = 0.05

    # ---- convenience accessors -------------------------------------------
    @property
    def state_lams(self) -> np.ndarray:
        """Mean-reversion speed of each *state* (X1 has none)."""
        return np.array([0.0, self.lam1, self.lam2, self.lam3])

    def beta(self, i: int, t):
        """Diffusion coefficient beta of state i (0-based), eq. (2)/(22)."""
        t = np.asarray(t, dtype=float)
        if i == 0:
            return np.broadcast_to(self.c, t.shape).copy() if t.shape else self.c
        a0, a1 = [(self.a0_1, self.a1_1),
                  (self.a0_2, self.a1_2),
                  (self.a0_3, self.a1_3)][i - 1]
        return a0 + a1 * t

    def state_factor(self, i: int) -> int:
        """Driving Brownian motion (0-based factor index) of state i."""
        return [0, 0, 1, 2][i]


# ----------------------------------------------------------------------------
# Deterministic V^{(k)}_{ij}(t) functions  (definition eq. 5, closed forms A.1)
# ----------------------------------------------------------------------------
def _V_exp(a0, a1, lam, t):
    """V(t) = e^{-2 lam t} * int_0^t (a0 + a1 s)^2 e^{2 lam s} ds  (closed form).

    Matches V^{(1)}_{22}, V^{(2)}_{11}, V^{(3)}_{11} in Appendix A.1.
    """
    e = np.exp(-2.0 * lam * t)
    return (1.0 / (4.0 * lam ** 3)) * (
        2 * a0 ** 2 * lam ** 2
        + 2 * a0 * a1 * lam * (-1 + 2 * lam * t)
        - e * (a1 ** 2 - 2 * a0 * a1 * lam + 2 * a0 ** 2 * lam ** 2)
        + a1 ** 2 * (1 + 2 * lam * t * (-1 + lam * t))
    )


def V11(p: ModelParams, t):
    """V^{(1)}_{11}(t) = c^2 t."""
    return p.c ** 2 * np.asarray(t, dtype=float)


def V12(p: ModelParams, t):
    """V^{(1)}_{12}(t) = V^{(1)}_{21}(t), Appendix A.1."""
    lam, a0, a1 = p.lam1, p.a0_1, p.a1_1
    t = np.asarray(t, dtype=float)
    return (p.c / lam ** 2) * (
        -a1 + a0 * lam + np.exp(-lam * t) * (a1 - a0 * lam) + a1 * lam * t
    )


def V22(p: ModelParams, t):
    return _V_exp(p.a0_1, p.a1_1, p.lam1, np.asarray(t, dtype=float))


def V2_11(p: ModelParams, t):
    return _V_exp(p.a0_2, p.a1_2, p.lam2, np.asarray(t, dtype=float))


def V3_11(p: ModelParams, t):
    return _V_exp(p.a0_3, p.a1_3, p.lam3, np.asarray(t, dtype=float))


def V_quad(p: ModelParams, which: str, t: float) -> float:
    """Direct quadrature of definition (5) -- used to self-test closed forms."""
    if which == "11":
        alpha_i = alpha_j = lambda s: 1.0
        beta_i = beta_j = lambda s: p.c
    elif which == "12":
        alpha_i, beta_i = (lambda s: 1.0), (lambda s: p.c)
        alpha_j = lambda s: np.exp(-p.lam1 * s)
        beta_j = lambda s: p.a0_1 + p.a1_1 * s
    elif which == "22":
        alpha_i = alpha_j = lambda s: np.exp(-p.lam1 * s)
        beta_i = beta_j = lambda s: p.a0_1 + p.a1_1 * s
    elif which == "2_11":
        alpha_i = alpha_j = lambda s: np.exp(-p.lam2 * s)
        beta_i = beta_j = lambda s: p.a0_2 + p.a1_2 * s
    elif which == "3_11":
        alpha_i = alpha_j = lambda s: np.exp(-p.lam3 * s)
        beta_i = beta_j = lambda s: p.a0_3 + p.a1_3 * s
    else:
        raise ValueError(which)
    integ, _ = quad(lambda s: beta_i(s) * beta_j(s) / (alpha_i(s) * alpha_j(s)),
                    0.0, t)
    return alpha_i(t) * alpha_j(t) * integ


# ----------------------------------------------------------------------------
# Analytic bond price  (Theorem 4.1 / Lemma 4.2)
# ----------------------------------------------------------------------------
def G_vec(p: ModelParams, t, T):
    """Loadings G^{(k)}_j(t,T) of the four states in the bond exponent."""
    t = np.asarray(t, dtype=float)
    T = np.asarray(T, dtype=float)
    tau = T - t
    g1 = tau
    g2 = (1.0 - np.exp(-p.lam1 * tau)) / p.lam1
    g3 = (1.0 - np.exp(-p.lam2 * tau)) / p.lam2
    g4 = (1.0 - np.exp(-p.lam3 * tau)) / p.lam3
    return np.stack(np.broadcast_arrays(g1, g2, g3, g4), axis=-1)


def H_func(p: ModelParams, t, T):
    """Convexity term H(t,T) of Lemma 4.2, written compactly as
    H = 1/2 sum_{i,j within factor} G_i G_j V_ij."""
    g = G_vec(p, t, T)
    g1, g2, g3, g4 = g[..., 0], g[..., 1], g[..., 2], g[..., 3]
    return (0.5 * g1 ** 2 * V11(p, t) + g1 * g2 * V12(p, t)
            + 0.5 * g2 ** 2 * V22(p, t)
            + 0.5 * g3 ** 2 * V2_11(p, t)
            + 0.5 * g4 ** 2 * V3_11(p, t))


def disc0(p: ModelParams, T):
    """Initial discount curve B(0,T) (flat forward curve f0)."""
    return np.exp(-p.f0 * np.asarray(T, dtype=float))


def bond_price(p: ModelParams, t, T, x):
    """Zero-coupon bond B(t,T) given state x (shape (...,4)), eq. (13)."""
    x = np.asarray(x, dtype=float)
    g = G_vec(p, t, T)
    expo = -(x * g).sum(axis=-1) - H_func(p, t, T)
    return disc0(p, T) / disc0(p, t) * np.exp(expo)


# ----------------------------------------------------------------------------
# Bond price volatility b_k(t,T)  (eq. 18, Section 4.2.1)
# ----------------------------------------------------------------------------
def bond_vol(p: ModelParams, k: int, t, T):
    """b_k(t,T) = -int_t^T sigma_k(t,u) du for factor k in {0,1,2} (0-based).

    b_1 = -(c (T-t) + beta_2(t) G2),  b_2 = -beta_3(t) G3,  b_3 = -beta_4(t) G4,
    identical to the explicit expressions in Section 4.2.1.
    """
    t = np.asarray(t, dtype=float)
    tau = np.asarray(T, dtype=float) - t
    if k == 0:
        g2 = (1.0 - np.exp(-p.lam1 * tau)) / p.lam1
        return -(p.c * tau + (p.a0_1 + p.a1_1 * t) * g2)
    if k == 1:
        g3 = (1.0 - np.exp(-p.lam2 * tau)) / p.lam2
        return -(p.a0_2 + p.a1_2 * t) * g3
    if k == 2:
        g4 = (1.0 - np.exp(-p.lam3 * tau)) / p.lam3
        return -(p.a0_3 + p.a1_3 * t) * g4
    raise ValueError(k)


# ----------------------------------------------------------------------------
# Analytic caplet price  (eq. 20; v^2 of Appendix A.2 by quadrature)
# ----------------------------------------------------------------------------
def caplet_v2(p: ModelParams, TC: float, TB: float, t: float = 0.0) -> float:
    """v^2(t,TC,TB) = sum_k int_t^{TC} (b_k(u,TB)-b_k(u,TC))^2 du."""
    total = 0.0
    for k in range(3):
        val, _ = quad(lambda u, k=k: (bond_vol(p, k, u, TB)
                                      - bond_vol(p, k, u, TC)) ** 2, t, TC)
        total += val
    return total


def caplet_analytic(p: ModelParams, TC: float, TB: float, K: float) -> float:
    """Time-0 price of a caplet on LIBOR R(TC,TB) with strike K, eq. (20)."""
    delta = TB - TC
    Bc, Bb = float(disc0(p, TC)), float(disc0(p, TB))
    v = np.sqrt(caplet_v2(p, TC, TB))
    kk = 1.0 + K * delta
    d1 = (np.log(Bc / (Bb * kk)) + 0.5 * v * v) / v
    d2 = d1 - v
    return Bc * norm.cdf(d1) - Bb * kk * norm.cdf(d2)


def caplet_payoff_at_fixing(p: ModelParams, TC: float, TB: float, K: float, x):
    """PDE terminal condition at t = TC (Theorem 7.4).

    phi(x) = B(TC,TB,x) * Delta * max(R - K, 0) = max(1 - (1+K Delta) B(TC,TB,x), 0),
    which is algebraically identical to the paper's expression in terms of the
    K_i(X_i,TC,TB) functions (eqs 36-39), since sum_i K_i = -ln(B) - Delta f0 + H.
    """
    B = bond_price(p, TC, TB, x)
    return np.maximum(1.0 - (1.0 + K * (TB - TC)) * B, 0.0)


# ----------------------------------------------------------------------------
# Swaps / swaptions (Section 8.3-8.4)
# ----------------------------------------------------------------------------
def swap_value(p: ModelParams, t, x, T0: float, TN: float, K: float,
               tenor: float = 1.0):
    """Value at time t of a (forward) payer swap starting at T0 with fixed
    rate K, annual tenor, payment dates T0+tenor, ..., T0+TN.

    V = B(t,T0) - B(t,T0+TN) - K * tenor * sum_j B(t, T0 + j*tenor).
    """
    n = int(round(TN / tenor))
    pays = T0 + tenor * np.arange(1, n + 1)
    ann = sum(tenor * bond_price(p, t, Ti, x) for Ti in pays)
    return (bond_price(p, t, T0, x) - bond_price(p, t, pays[-1], x) - K * ann)


def swaption_payoff(p: ModelParams, t, x, T0, TN, K, tenor=1.0):
    """(Forward-)swaption exercise value max(V_swap, 0)."""
    return np.maximum(swap_value(p, t, x, T0, TN, K, tenor), 0.0)


# ----------------------------------------------------------------------------
# Black implied caplet volatility (the paper's error metric)
# ----------------------------------------------------------------------------
def black_caplet(p: ModelParams, TC, TB, K, sigma):
    delta = TB - TC
    R0 = (float(disc0(p, TC)) / float(disc0(p, TB)) - 1.0) / delta
    v = sigma * np.sqrt(TC)
    d1 = (np.log(R0 / K) + 0.5 * v * v) / v
    d2 = d1 - v
    return delta * float(disc0(p, TB)) * (R0 * norm.cdf(d1) - K * norm.cdf(d2))


def implied_vol(p: ModelParams, TC, TB, K, price):
    try:
        return brentq(lambda s: black_caplet(p, TC, TB, K, s) - price,
                      1e-6, 5.0, xtol=1e-12)
    except ValueError:
        return np.nan


# ----------------------------------------------------------------------------
# Self test: closed forms vs quadrature
# ----------------------------------------------------------------------------
def selftest(p: ModelParams | None = None, t: float = 4.0) -> dict:
    p = p or ModelParams()
    out = {}
    for name, fn in [("11", V11), ("12", V12), ("22", V22),
                     ("2_11", V2_11), ("3_11", V3_11)]:
        cf = float(fn(p, t))
        qd = V_quad(p, name, t)
        out[name] = (cf, qd, abs(cf - qd))
    return out
