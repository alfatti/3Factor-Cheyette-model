"""
GPU (PyTorch) exact Monte Carlo / scrambled-Sobol QMC for European payoffs.

The state vector at the payoff date is exactly Gaussian under the T-forward
measure (Theorem 6.1); its mean / covariance come from `montecarlo.forward_moments`
(scalar quadrature on the CPU, negligible cost).  Sampling and payoff
evaluation run on the device, batched over all contracts that share the
payoff date, so a whole strike/tenor grid costs one set of draws.

price = B(0,T) * E^T[ payoff(X_T) ]     (numeraire B(.,T))
"""
from __future__ import annotations

from typing import Sequence
import numpy as np
import torch

from .model import ModelParams, G_vec, H_func, disc0
from .montecarlo import forward_moments
from .pde_torch import get_device


def sample_states_t(p: ModelParams, t: float, T: float, n: int, device=None,
                    dtype=torch.float64, qmc: bool = False, seed: int = 0):
    """n exact samples of X(t) under the T-forward measure, shape (n,4)."""
    device = get_device(device)
    _, m, S = forward_moments(p, 0.0, t, T)
    L = np.linalg.cholesky(S + 1e-30 * np.eye(4))
    if qmc:
        eng = torch.quasirandom.SobolEngine(4, scramble=True, seed=seed)
        u = eng.draw(n).to(device=device, dtype=dtype)
        u = u.clamp(1e-12, 1 - 1e-12)
        z = torch.special.ndtri(u)
    else:
        gen = torch.Generator(device=device).manual_seed(seed)
        z = torch.randn(n, 4, generator=gen, device=device, dtype=dtype)
    Lt = torch.as_tensor(L.T, device=device, dtype=dtype)
    mt = torch.as_tensor(m, device=device, dtype=dtype)
    return z @ Lt + mt


def bond_price_samples(p: ModelParams, t: float, T: float, X: torch.Tensor):
    """B(t,T) for a batch of states X (n,4) -> (n,)."""
    g = torch.as_tensor(G_vec(p, t, T), device=X.device, dtype=X.dtype)
    scale = float(disc0(p, T) / disc0(p, t)) * float(np.exp(-H_func(p, t, T)))
    return scale * torch.exp(-(X @ g))


def swap_value_samples(p, t, X, T0, TN, K, tenor=1.0, notional=1.0, payer=True):
    n = int(round(TN / tenor))
    pays = T0 + tenor * np.arange(1, n + 1)
    ann = sum(tenor * bond_price_samples(p, t, float(Ti), X) for Ti in pays)
    v = (bond_price_samples(p, t, T0, X) - bond_price_samples(p, t, float(pays[-1]), X)
         - K * ann)
    return notional * (v if payer else -v)


def _payoff_samples(p, c, X):
    """European payoff at the contract horizon for states X (n,4)."""
    name = type(c).__name__
    if name == "Caplet":
        B = bond_price_samples(p, c.TC, c.TB, X)
        return torch.clamp(1.0 - (1.0 + c.K * (c.TB - c.TC)) * B, min=0.0)
    if name == "Swaption":
        return torch.clamp(swap_value_samples(p, c.T0, X, c.T0, c.TN, c.K,
                                              c.tenor, c.notional, c.payer), min=0.0)
    if name == "Swap":
        return swap_value_samples(p, c.T0, X, c.T0, c.TN, c.K, c.tenor,
                                  c.notional, c.payer)
    if name == "Bond":
        return torch.ones(X.shape[0], device=X.device, dtype=X.dtype)
    raise ValueError(f"no Monte Carlo payoff for {name}")


def price_mc(p: ModelParams, contracts: Sequence, n: int = 1 << 18,
             qmc: bool = True, seed: int = 0, device=None,
             dtype=torch.float64):
    """European MC/QMC prices (and standard errors for pseudo-random MC).

    Returns (prices, stderr) arrays in input order; stderr is NaN for QMC.
    """
    device = get_device(device)
    contracts = list(contracts)
    groups: dict = {}
    for i, c in enumerate(contracts):
        groups.setdefault(round(c.horizon, 10), []).append(i)
    prices = np.full(len(contracts), np.nan)
    ses = np.full(len(contracts), np.nan)
    for T, idx in groups.items():
        if T <= 0.0:
            prices[idx] = [contracts[i].analytic(p) for i in idx]
            ses[idx] = 0.0
            continue
        X = sample_states_t(p, T, T, n, device, dtype, qmc, seed)
        D = float(disc0(p, T))
        for i in idx:
            pay = _payoff_samples(p, contracts[i], X)
            prices[i] = D * float(pay.mean())
            if not qmc:
                ses[i] = D * float(pay.std()) / np.sqrt(n)
    return prices, ses
