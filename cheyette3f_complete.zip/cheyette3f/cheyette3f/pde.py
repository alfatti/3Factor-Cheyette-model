"""
PDE valuation (Section 7, Appendix E) for the 3 Factor Exponential Model.

The valuation PDE (Theorem 7.3) for g(t, x1..x4):

  g_t + sum_i b_i(t,x) g_{x_i} + 1/2 sum_{ij} [sigma sigma^T]_{ij}(t) g_{x_i x_j}
      - (f(0,t) + sum_i x_i) g = 0,   g(T, x) = phi(x),

with drifts
  b1 = V11 + V12,                b2 = -lam1 x2 + V12 + V22,
  b3 = -lam2 x3 + V2_11,         b4 = -lam3 x4 + V3_11,
and diffusion matrix (eq. 22)
  [sigma sigma^T] = [[c^2, c b2t, 0, 0], [c b2t, b2t^2, 0, 0],
                     [0,0,b3t^2,0], [0,0,0,b4t^2]],   b_it = beta_i(t).

Numerics (Appendix E):
  * theta-scheme in time (Rannacher: first steps fully implicit, then
    Crank-Nicolson), central differences in space, "linearity" boundary
    condition g_{x_i x_i} = 0 on the boundary,
  * the *modified* sparse grid combination technique (E.2.2): per-dimension
    levels start from ls_j (the paper's "added points", applied to the x1/x2
    directions where the large mixed derivative lives), and sub-solutions on
    all grids with |l|_1 = l, l-1, l-2, l-3 are combined with coefficients
    (+1, -3, +3, -1) (the d=4 combination formula, cf. eq. 47/48),
  * Bermudan exercise by applying max(g, exercise value) at exercise dates
    (equivalent to the PSOR/LCP treatment (43)-(46) when exercise is
    restricted to discrete dates).

Prices are read off by multilinear interpolation at x = 0 (today's state).
"""
from __future__ import annotations

from itertools import product
from math import comb
import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve

from .model import ModelParams, V11, V12, V22, V2_11, V3_11
from .montecarlo import state_stds


# ----------------------------------------------------------------------------
# 1-D difference operators
# ----------------------------------------------------------------------------
def _d1(x: np.ndarray) -> sp.csr_matrix:
    """First derivative: central inside, one-sided at the ends."""
    n = len(x)
    D = sp.lil_matrix((n, n))
    if n == 1:
        return D.tocsr()
    for i in range(1, n - 1):
        h = x[i + 1] - x[i - 1]
        D[i, i - 1], D[i, i + 1] = -1.0 / h, 1.0 / h
    D[0, 0], D[0, 1] = -1.0 / (x[1] - x[0]), 1.0 / (x[1] - x[0])
    D[n - 1, n - 2] = -1.0 / (x[-1] - x[-2])
    D[n - 1, n - 1] = 1.0 / (x[-1] - x[-2])
    return D.tocsr()


def _d2(x: np.ndarray) -> sp.csr_matrix:
    """Second derivative: standard 3-point inside, zero rows at the ends
    (the linearity boundary condition g'' = 0)."""
    n = len(x)
    D = sp.lil_matrix((n, n))
    for i in range(1, n - 1):
        hm, hp = x[i] - x[i - 1], x[i + 1] - x[i]
        D[i, i - 1] = 2.0 / (hm * (hm + hp))
        D[i, i] = -2.0 / (hm * hp)
        D[i, i + 1] = 2.0 / (hp * (hm + hp))
    return D.tocsr()


def _kron4(mats) -> sp.csr_matrix:
    out = mats[0]
    for m in mats[1:]:
        out = sp.kron(out, m, format="csr")
    return out


def _op_in_dim(mat: sp.spmatrix, dim: int, ns) -> sp.csr_matrix:
    mats = [sp.identity(n, format="csr") for n in ns]
    mats[dim] = mat
    return _kron4(mats)


# ----------------------------------------------------------------------------
# Single tensor-grid solver
# ----------------------------------------------------------------------------
def solve_on_grid(p: ModelParams, levels, halfwidths, T: float, payoff_fn,
                  dt: float, theta: float = 0.5, rannacher: int = 4,
                  exercise_dates=None, exercise_fn=None,
                  eval_point=None) -> float:
    """Solve the valuation PDE backward from t=T to t=0 on the tensor grid
    with 2^levels[j]+1 points in dimension j, and return g(0, eval_point)."""
    eval_point = np.zeros(4) if eval_point is None else np.asarray(eval_point)
    xs = [np.linspace(-R, R, 2 ** lv + 1)
          for lv, R in zip(levels, halfwidths)]
    ns = [len(x) for x in xs]
    N = int(np.prod(ns))

    mesh = np.meshgrid(*xs, indexing="ij")
    Xf = np.column_stack([m.ravel() for m in mesh])          # (N,4)
    xsum = Xf.sum(axis=1)

    L1 = [_op_in_dim(_d1(xs[j]), j, ns) for j in range(4)]
    L2 = [_op_in_dim(_d2(xs[j]), j, ns) for j in range(4)]
    Lmix = _kron4([_d1(xs[0]), _d1(xs[1]),
                   sp.identity(ns[2], format="csr"),
                   sp.identity(ns[3], format="csr")])

    lams = p.state_lams
    # time-independent part: mean reversion drifts, c^2/2 g_11, -r(x) term
    A0 = 0.5 * p.c ** 2 * L2[0] - sp.diags(p.f0 + xsum)
    for j in (1, 2, 3):
        A0 = A0 + (sp.diags(-lams[j] * Xf[:, j]) @ L1[j])
    A0 = A0.tocsr()

    def A_of_t(t: float) -> sp.csr_matrix:
        b2t, b3t, b4t = p.beta(1, t), p.beta(2, t), p.beta(3, t)
        A = (A0
             + float(V11(p, t) + V12(p, t)) * L1[0]
             + float(V12(p, t) + V22(p, t)) * L1[1]
             + float(V2_11(p, t)) * L1[2]
             + float(V3_11(p, t)) * L1[3]
             + 0.5 * b2t ** 2 * L2[1]
             + 0.5 * b3t ** 2 * L2[2]
             + 0.5 * b4t ** 2 * L2[3]
             + p.c * b2t * Lmix)
        return A.tocsr()

    n_steps = int(round(T / dt))
    ex = sorted(exercise_dates or [])
    g = np.asarray(payoff_fn(Xf), dtype=float)
    I = sp.identity(N, format="csr")

    for m in range(n_steps):
        t_old = T - m * dt
        t_new = T - (m + 1) * dt
        th = 1.0 if m < rannacher else theta
        rhs = g + (1.0 - th) * dt * (A_of_t(t_old) @ g)
        lhs = (I - th * dt * A_of_t(t_new)).tocsc()
        g = spsolve(lhs, rhs)
        for te in ex:
            if abs(t_new - te) < 0.5 * dt:
                g = np.maximum(g, exercise_fn(te, Xf))

    return _interp(xs, g.reshape(ns), eval_point)


def _interp(xs, grid, pt) -> float:
    """Multilinear interpolation of a 4-D tensor grid at point pt."""
    idxw = []
    for x, q in zip(xs, pt):
        if len(x) == 1:
            idxw.append([(0, 1.0)])
            continue
        i = int(np.clip(np.searchsorted(x, q) - 1, 0, len(x) - 2))
        w = (q - x[i]) / (x[i + 1] - x[i])
        idxw.append([(i, 1.0 - w), (i + 1, w)])
    val = 0.0
    for combo in product(*idxw):
        w = np.prod([c[1] for c in combo])
        if w:
            val += w * grid[tuple(c[0] for c in combo)]
    return float(val)


# ----------------------------------------------------------------------------
# Modified sparse grid combination technique (Appendix E.2)
# ----------------------------------------------------------------------------
def _compositions(total: int, parts: int):
    if parts == 1:
        yield (total,)
        return
    for i in range(total + 1):
        for rest in _compositions(total - i, parts - 1):
            yield (i,) + rest


def combination_price(p: ModelParams, T: float, payoff_fn, level: int = 3,
                      ls=(3, 3, 0, 0), dt: float = 1.0 / 96,
                      halfwidths=None, width_mult: float = 6.0,
                      exercise_dates=None, exercise_fn=None,
                      verbose: bool = False) -> float:
    """Price via the d=4 combination formula on the *modified* sparse grid:

      u = sum_{q=0}^{3} (-1)^q C(3,q) sum_{|i|_1 = level - q} u_{i + ls}.
    """
    if halfwidths is None:
        s = state_stds(p, T)
        halfwidths = width_mult * np.maximum(s, 1e-6)
    total = 0.0
    for q in range(4):
        lv = level - q
        if lv < 0:
            continue
        coef = (-1) ** q * comb(3, q)
        for compo in _compositions(lv, 4):
            levels = tuple(c + l0 for c, l0 in zip(compo, ls))
            v = solve_on_grid(p, levels, halfwidths, T, payoff_fn, dt,
                              exercise_dates=exercise_dates,
                              exercise_fn=exercise_fn)
            total += coef * v
            if verbose:
                print(f"  grid {levels}: {v:.8f} (coef {coef:+d})")
    return total
