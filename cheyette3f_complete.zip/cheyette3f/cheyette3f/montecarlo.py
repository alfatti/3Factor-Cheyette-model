"""
(Quasi-)Monte Carlo pricing (Sections 6, 8) for the 3 Factor Exponential Model.

Because the model is Gaussian with deterministic coefficients, the state
variables are exactly normally distributed (Theorem 6.1); sample paths are
constructed with *no discretization error* from the joint distribution.
Under the T-forward measure only the drift changes (Lemma 4.3):

    dX_i gets the extra drift  beta_i(t) * b_{k(i)}(t,T) dt,

where b_k is the bond-price volatility of the driving factor k(i).

The moments below are computed by adaptive quadrature of their defining
integrals (equivalent to -- and numerically safer than transcribing -- the
closed forms (28)-(35) in Appendix D.2).

Note: the paper's covariance cov(X1,X2) = c (a1 t^2/2 + a0 t) (pp. 51-53)
drops the mean-reversion kernel exp(-lam1 (t-s)) of X2's stochastic integral.
We implement the exact covariance c * int_0^t e^{-lam1 (t-s)} beta_2(s) ds;
with lam1 = -0.004 the difference is negligible but the exact form is used.
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import quad
from scipy.stats import qmc

from .model import (ModelParams, V11, V12, V22, V2_11, V3_11, bond_vol,
                    bond_price, disc0, swaption_payoff)


# ----------------------------------------------------------------------------
# Exact conditional moments of the state vector under the T-forward measure
# ----------------------------------------------------------------------------
def _drift_Q(p: ModelParams, i: int, s):
    """Risk-neutral drift of state i excluding the -lam*x mean reversion."""
    if i == 0:
        return V11(p, s) + V12(p, s)
    if i == 1:
        return V12(p, s) + V22(p, s)
    if i == 2:
        return V2_11(p, s)
    if i == 3:
        return V3_11(p, s)
    raise ValueError(i)


def forward_moments(p: ModelParams, t1: float, t2: float, T: float):
    """Conditional law of X(t2) given X(t1) under the T-forward measure.

    Returns (d, m, Sigma) with X(t2) = d * X(t1) + m + eps,
    eps ~ N(0, Sigma), d_i = exp(-lam_i (t2-t1)).
    """
    lams = p.state_lams
    d = np.exp(-lams * (t2 - t1))
    m = np.zeros(4)
    var = np.zeros(4)
    for i in range(4):
        k = p.state_factor(i)
        lam = lams[i]

        def drift(s, i=i, k=k):
            return _drift_Q(p, i, s) + p.beta(i, s) * bond_vol(p, k, s, T)

        m[i], _ = quad(lambda s: drift(s) * np.exp(lam * (s - t2)), t1, t2)
        var[i], _ = quad(lambda s: np.exp(-2.0 * lam * (t2 - s))
                         * p.beta(i, s) ** 2, t1, t2)
    cov12, _ = quad(lambda s: p.c * np.exp(-p.lam1 * (t2 - s))
                    * p.beta(1, s), t1, t2)
    Sigma = np.diag(var)
    Sigma[0, 1] = Sigma[1, 0] = cov12
    return d, m, Sigma


def state_stds(p: ModelParams, T: float) -> np.ndarray:
    """Unconditional (risk-neutral) std of each state at horizon T."""
    _, _, S = forward_moments(p, 0.0, T, T)  # measure choice irrelevant for var
    return np.sqrt(np.diag(S))


# ----------------------------------------------------------------------------
# Sampling
# ----------------------------------------------------------------------------
def _normals(n: int, dim: int, qmc_engine: bool, seed=0):
    if qmc_engine:
        sob = qmc.Sobol(d=dim, scramble=True, seed=seed)
        u = sob.random(n)
        u = np.clip(u, 1e-12, 1 - 1e-12)
        from scipy.stats import norm as _norm
        return _norm.ppf(u)
    rng = np.random.default_rng(seed)
    return rng.standard_normal((n, dim))


def sample_states(p: ModelParams, t: float, T: float, n: int,
                  use_qmc: bool = False, seed: int = 0) -> np.ndarray:
    """Exact samples of X(t) (X(0)=0) under the T-forward measure."""
    _, m, Sigma = forward_moments(p, 0.0, t, T)
    L = np.linalg.cholesky(Sigma + 1e-30 * np.eye(4))
    Z = _normals(n, 4, use_qmc, seed)
    return m + Z @ L.T


# ----------------------------------------------------------------------------
# Pricers
# ----------------------------------------------------------------------------
def caplet_mc(p: ModelParams, TC, TB, K, n=500_000, use_qmc=False, seed=0):
    """Caplet under the TB-forward measure (eq. 16); returns (price, stderr)."""
    X = sample_states(p, TC, TB, n, use_qmc, seed)
    B = bond_price(p, TC, TB, X)
    payoff = np.maximum(1.0 / B - (1.0 + K * (TB - TC)), 0.0)
    df = float(disc0(p, TB))
    price = df * payoff.mean()
    stderr = df * payoff.std(ddof=1) / np.sqrt(n)
    return price, stderr


def eur_swaption_mc(p: ModelParams, T0, TN, K, tenor=1.0, n=500_000,
                    use_qmc=False, seed=0):
    """European payer swaption under the T0-forward measure."""
    X = sample_states(p, T0, T0, n, use_qmc, seed)
    payoff = swaption_payoff(p, T0, X, T0, TN, K, tenor)
    df = float(disc0(p, T0))
    return df * payoff.mean(), df * payoff.std(ddof=1) / np.sqrt(n)


def _poly_basis(X: np.ndarray) -> np.ndarray:
    """Quadratic polynomial basis in the 4 states (15 features)."""
    n = X.shape[0]
    cols = [np.ones(n)]
    for i in range(4):
        cols.append(X[:, i])
    for i in range(4):
        for j in range(i, 4):
            cols.append(X[:, i] * X[:, j])
    return np.column_stack(cols)


def bermudan_swaption_mc(p: ModelParams, T0, TN, K, TEx, tenor=1.0,
                         n=400_000, use_qmc=False, seed=0):
    """Bermudan payer swaption exercisable at {TEx, T0} into the swap
    starting at T0 -- Longstaff-Schwartz with exact 2-date sampling under
    the T0-forward measure (numeraire B(., T0))."""
    # X at TEx
    _, m1, S1 = forward_moments(p, 0.0, TEx, T0)
    L1 = np.linalg.cholesky(S1 + 1e-30 * np.eye(4))
    Z = _normals(n, 8, use_qmc, seed)
    X1 = m1 + Z[:, :4] @ L1.T
    # X at T0 given X at TEx
    d2, m2, S2 = forward_moments(p, TEx, T0, T0)
    L2 = np.linalg.cholesky(S2 + 1e-30 * np.eye(4))
    X2 = X1 * d2 + m2 + Z[:, 4:] @ L2.T

    # deflated cashflows (numeraire B(t,T0); B(T0,T0)=1)
    h_T0 = swaption_payoff(p, T0, X2, T0, TN, K, tenor)
    intr = swaption_payoff(p, TEx, X1, T0, TN, K, tenor)
    intr_defl = intr / bond_price(p, TEx, T0, X1)

    # continuation value at TEx by regression (on ITM paths)
    itm = intr > 0
    cont = np.zeros(n)
    if itm.sum() > 50:
        A = _poly_basis(X1[itm])
        coef, *_ = np.linalg.lstsq(A, h_T0[itm], rcond=None)
        cont[itm] = A @ coef
    exercise = itm & (intr_defl > cont)
    cf = np.where(exercise, intr_defl, h_T0)
    df = float(disc0(p, T0))
    return df * cf.mean(), df * cf.std(ddof=1) / np.sqrt(n)
