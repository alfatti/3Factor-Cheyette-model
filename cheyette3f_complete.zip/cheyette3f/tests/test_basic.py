"""Smoke tests (python -m pytest tests -q). Coarse grids -> ~30 s on a CPU."""
import numpy as np, torch
from cheyette3f import *
from cheyette3f.pde import solve_on_grid
from cheyette3f.pde_torch import solve_on_grid_t

p = ModelParams()


def test_v_closed_forms():
    for k, (cf, qd, d) in selftest(p).items():
        assert d < 1e-12, k


def test_caplets_match_paper_table5():
    paper = {1: 0.004183, 2: 0.005318, 3: 0.006077, 4: 0.006792, 5: 0.007788}
    for TC, v in paper.items():
        assert abs(caplet_analytic(p, TC, TC + 1, 0.05) - v) < 1e-6


def test_torch_solver_matches_scipy_solver():
    hw = 6 * np.maximum(state_stds(p, 1.0), 1e-6)
    v_np = solve_on_grid(p, (3, 3, 1, 1), hw, 1.0,
                         lambda X: caplet_payoff_at_fixing(p, 1.0, 2.0, 0.05, X), 1 / 48)
    v_t = solve_on_grid_t(p, (3, 3, 1, 1), hw, 1.0,
                          lambda g: Caplet(1.0, 2.0, 0.05).payoff(p, g), 1 / 48)
    assert abs(v_np - float(v_t[0])) < 1e-9


def test_pde_reproduces_linear_payoffs_and_swap_pricer():
    cs = [Swap(1.0, 3.0, K) for K in (0.03, 0.05, 0.07)] + [Bond(1.0)]
    v = price_pde(p, cs, level=2, ls=(2, 2, 0, 0), dt=1 / 48)
    a = price_analytic(p, cs)
    assert np.max(np.abs(v - a)) < 1e-5
    s = Swap(1.0, 5.0, 0.05)
    assert abs(Swap(1.0, 5.0, s.par_rate(p)).value(p)) < 1e-14
    assert abs(s.dv01(p) - (Swap(1.0, 5.0, 0.0501).value(p) - s.value(p))) < 1e-12


def test_qmc_matches_analytic_caplets():
    cs = [Caplet(1.0, 2.0, K) for K in (0.03, 0.05, 0.07)]
    v, _ = price_mc(p, cs, n=1 << 16, qmc=True)
    assert np.max(np.abs(v - price_analytic(p, cs))) < 5e-6


def test_same_swap_bermudan_has_no_premium_at_convergence_order():
    eur = price_pde(p, [Swaption(1.0, 3.0, 0.05)], level=2, ls=(2, 2, 0, 0), dt=1 / 48)
    berm = price_pde(p, [BermudanSwaption(1.0, 3.0, 0.05, (0.5,), sliding=False)],
                     level=2, ls=(2, 2, 0, 0), dt=1 / 48)
    assert berm[0] >= eur[0] - 1e-12          # max() can only increase the value
    assert berm[0] - eur[0] < 1e-3           # and the premium is a discretisation artefact
