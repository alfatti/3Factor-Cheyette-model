"""
Reproduce the numerical experiments of Beyna, Chiarella & Kang (2012),
Section 8, at reduced (but representative) numerical settings.

Run:  python run_experiments.py [--fast]
"""
import argparse
import time

import numpy as np

from cheyette3f import (ModelParams, selftest, disc0, caplet_analytic,
                        implied_vol, caplet_mc, eur_swaption_mc,
                        bermudan_swaption_mc, caplet_payoff_at_fixing,
                        swaption_payoff, combination_price)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true",
                    help="smaller grids / fewer paths")
    args = ap.parse_args()
    fast = args.fast

    p = ModelParams()
    np.set_printoptions(precision=6, suppress=True)

    # ------------------------------------------------------------------
    print("=" * 72)
    print("0. Self-test: closed-form V functions vs quadrature (t = 4)")
    for k, (cf, qd, err) in selftest(p).items():
        print(f"   V_{k:<5}  closed {cf:+.6e}   quad {qd:+.6e}   |diff| {err:.1e}")

    # ------------------------------------------------------------------
    print("=" * 72)
    print("1. Analytic zero-coupon bonds B(0,T)   [paper Table 3, col 2]")
    for T in (2, 4, 6, 8, 10):
        print(f"   T={T:2d}: {float(disc0(p, T)):.6f}")

    # ------------------------------------------------------------------
    print("=" * 72)
    print("2. Analytic ATM caplets (K=5%)         [paper Table 5, col 3]")
    paper5 = {1: 0.004183, 2: 0.005318, 3: 0.006077, 4: 0.006792, 5: 0.007788}
    for TC in (1, 2, 3, 4, 5):
        c = caplet_analytic(p, TC, TC + 1, 0.05)
        iv = implied_vol(p, TC, TC + 1, 0.05, c)
        print(f"   TC={TC} TB={TC+1}: {c:.6f}  (paper {paper5[TC]:.6f}, "
              f"diff {abs(c - paper5[TC]):.1e})  impl.vol {100*iv:.2f}%")

    # ------------------------------------------------------------------
    print("=" * 72)
    n_mc = 100_000 if fast else 1_000_000
    n_qmc = 2 ** 14 if fast else 2 ** 17
    print(f"3. Caplet MC ({n_mc:,} paths) and Sobol QMC ({n_qmc:,} paths), "
          "exact distributions under the TB-forward measure")
    for TC in (1, 3, 5):
        ana = caplet_analytic(p, TC, TC + 1, 0.05)
        t0 = time.time()
        mc, se = caplet_mc(p, TC, TC + 1, 0.05, n=n_mc, seed=42)
        t1 = time.time()
        qmcp, _ = caplet_mc(p, TC, TC + 1, 0.05, n=n_qmc, use_qmc=True, seed=7)
        t2 = time.time()
        print(f"   TC={TC}: analytic {ana:.6f} | MC {mc:.6f} "
              f"(err {abs(mc-ana):.1e}, se {se:.1e}, {t1-t0:.1f}s) | "
              f"QMC {qmcp:.6f} (err {abs(qmcp-ana):.1e}, {t2-t1:.1f}s)")

    # ------------------------------------------------------------------
    print("=" * 72)
    lvl = 2 if fast else 3
    dt_b = 1 / 24 if fast else 1 / 48
    print(f"4. PDE bonds via modified sparse grid (level {lvl}, ls=(2,2,0,0), "
          f"dt={dt_b:.4f})   [paper Table 3]")
    for T in (2, 4):
        t0 = time.time()
        v = combination_price(p, T, lambda X: np.ones(len(X)), level=lvl,
                              ls=(2, 2, 0, 0), dt=dt_b)
        ana = float(disc0(p, T))
        print(f"   T={T}: PDE {v:.6f}  analytic {ana:.6f}  "
              f"err {abs(v-ana):.1e}   ({time.time()-t0:.0f}s)")

    # ------------------------------------------------------------------
    print("=" * 72)
    lvl_c = 2 if fast else 3
    ls_c = (2, 2, 0, 0) if fast else (3, 3, 0, 0)
    dt_c = 1 / 48 if fast else 1 / 96
    print(f"5. PDE caplet TC=1 TB=2 K=5% (level {lvl_c}, ls={ls_c}, "
          f"dt={dt_c:.4f})   [paper Table 7]")
    ana = caplet_analytic(p, 1.0, 2.0, 0.05)
    t0 = time.time()
    v = combination_price(p, 1.0,
                          lambda X: caplet_payoff_at_fixing(p, 1.0, 2.0, 0.05, X),
                          level=lvl_c, ls=ls_c, dt=dt_c)
    iv_err = abs(implied_vol(p, 1, 2, 0.05, v) - implied_vol(p, 1, 2, 0.05, ana))
    print(f"   PDE {v:.6f}  analytic {ana:.6f}  err {abs(v-ana):.1e}  "
          f"impl-vol err {100*iv_err:.4f}%   ({time.time()-t0:.0f}s)")

    # ------------------------------------------------------------------
    print("=" * 72)
    print("   (note: --fast grids are too coarse for reliable swaption PDE values)")
    print("6. European payer swaption T0=1, TN=3 (payments at 2,3,4)"
          "   [paper Table 10: PDE 0.011791, MC 0.011237 at K=5%]")
    for K in (0.03, 0.05, 0.07):
        t0 = time.time()
        v_pde = combination_price(
            p, 1.0, lambda X: swaption_payoff(p, 1.0, X, 1.0, 3.0, K),
            level=lvl_c, ls=ls_c, dt=dt_c)
        t1 = time.time()
        v_mc, se = eur_swaption_mc(p, 1.0, 3.0, K, n=n_mc, seed=11)
        print(f"   K={100*K:.0f}%: PDE {v_pde:.6f} ({t1-t0:.0f}s) | "
              f"MC {v_mc:.6f} (se {se:.1e}) | diff {abs(v_pde-v_mc):.1e}")

    # ------------------------------------------------------------------
    print("=" * 72)
    print("7. Bermudan payer swaption T0=1, TN=3, TEx=0.5"
          "   [paper Table 11: PDE 0.012930, MC 0.014581 at K=5%]")
    print("   NB: if exercise at TEx enters the SAME forward swap (the")
    print("   paper's stated definition), the deflated swap value is a")
    print("   Q^{T0}-martingale and the early-exercise premium is exactly 0.")
    print("   A positive premium (as in the paper's Table 12) requires the")
    print("   'sliding' convention: exercise at t enters a TN-year swap")
    print("   starting at t. Both are shown below (PDE).")
    for K in (0.03, 0.05, 0.07):
        pay = lambda X, K=K: swaption_payoff(p, 1.0, X, 1.0, 3.0, K)
        kw = dict(level=lvl_c, ls=ls_c, dt=dt_c)
        v_eur = combination_price(p, 1.0, pay, **kw)
        v_fwd = combination_price(
            p, 1.0, pay, exercise_dates=[0.5],
            exercise_fn=lambda t, X, K=K: swaption_payoff(p, t, X, 1.0, 3.0, K),
            **kw)
        v_sld = combination_price(
            p, 1.0, pay, exercise_dates=[0.5],
            exercise_fn=lambda t, X, K=K: swaption_payoff(p, t, X, t, 3.0, K),
            **kw)
        v_mc, se = bermudan_swaption_mc(p, 1.0, 3.0, K, 0.5,
                                        n=min(n_mc, 400_000), seed=3)
        print(f"   K={100*K:.0f}%: Eur {v_eur:.6f} | Berm(fwd) {v_fwd:.6f} "
              f"(prem {v_fwd-v_eur:+.6f}) | Berm(sliding) {v_sld:.6f} "
              f"(prem {v_sld-v_eur:+.6f}) | LS-MC(fwd) {v_mc:.6f}")

    print("=" * 72)
    print("Done.")


if __name__ == "__main__":
    main()
