# 3 Factor Exponential Cheyette Model — analytic, Monte Carlo and CUDA sparse-grid PDE pricing

Python implementation of **Beyna, Chiarella & Kang (2012), "Pricing Interest
Rate Derivatives in a Multifactor HJM Model with Time Dependent Volatility"**
(UTS QFRC Research Paper 317 / SSRN 2162748): the 3 Factor Exponential
(Markovian Gaussian HJM / Cheyette) model with four state variables, priced
by closed forms, exact (quasi-)Monte Carlo, and the paper's *modified*
sparse-grid PDE method — the latter re-engineered for GPUs.

```
cheyette3f/
  model.py            parameters (Table 2), V-functions (A.1), ANALYTIC BOND (Thm 4.1/Lemma 4.2),
                      bond vols, ANALYTIC CAPLET (eq. 20), Black implied vol
  contracts.py        Bond / Caplet / Swap (vanilla swap pricer) / Swaption / BermudanSwaption,
                      price_analytic, price_pde (batched GPU), implied vols
  pde_torch.py        CUDA sparse-grid PDE solver (PyTorch): matrix-free, batched, BiCGSTAB
  montecarlo_torch.py CUDA exact MC / scrambled-Sobol QMC, batched over contracts
  pde.py              reference CPU solver (scipy sparse LU) -- same discretisation
  montecarlo.py       reference CPU MC + Longstaff-Schwartz Bermudan, forward-measure moments
notebooks/
  01_bonds.ipynb, 02_caplets.ipynb, 03_vanilla_swaps.ipynb,
  04_european_swaptions.ipynb, 05_bermudan_swaptions.ipynb   price grids (PDE) per derivative
  make_notebooks.py (regenerates them), run_all.py (executes them headless)
run_experiments.py    reproduces the paper's Section 8 tables (CPU reference code)
bench_gpu.py          quick throughput check on your GPU
```

Dependencies: `numpy scipy torch` (+ `pandas matplotlib` for the notebooks,
`nbformat nbclient ipykernel` to run them headless). Any CUDA build of
PyTorch works; the code falls back to CPU automatically.

## Quick start (GPU)

```python
import torch
from cheyette3f import *

p = ModelParams()                                   # paper's calibration, f(0,t) = 5%

# closed forms
disc0(p, 5.0)                                       # B(0,5)
bond_price(p, t=1.0, T=5.0, x=[0.01, 0, 0, 0])      # B(t,T,x), Theorem 4.1
caplet_analytic(p, TC=2.0, TB=3.0, K=0.05)          # eq. (20)

# vanilla swap pricer
s = Swap(T0=1.0, TN=5.0, K=0.05, tenor=1.0, notional=1.0, payer=True)
s.value(p), s.par_rate(p), s.annuity(p), s.dv01(p)  # at t=0
s.value(p, t=0.5, x=[0.01, 0, 0, 0])                # mark-to-market at (t, x)

# batched CUDA sparse-grid PDE: a whole strike/tenor grid in a few solves
contracts = [Caplet(TC, TC + 1, K) for TC in (1, 2, 3) for K in (0.03, 0.05, 0.07)]
prices = price_pde(p, contracts, level=3, ls=(3, 3, 0, 0), dt=1/96,
                   device="cuda", dtype=torch.float64)
price_analytic(p, contracts)                        # reference

# exact QMC on the GPU (Europeans)
price_mc(p, [Swaption(1.0, 3.0, K) for K in (0.03, 0.05, 0.07)], n=1 << 18, qmc=True)
```

`price_pde` groups contracts by PDE horizon (and exercise schedule) and solves
each group as **one batched PDE**: the operator is contract-independent, only
the terminal/exercise data differ, so the cost of a grid of prices is
essentially the cost of one price. Bermudans: `BermudanSwaption(T0, TN, K,
exercise_dates=(0.5,), sliding=True)`.

## The CUDA solver (`pde_torch.py`)

Same discretisation as the paper / the CPU reference (`pde.py`): central
differences, one-sided first derivatives at the boundary, linearity boundary
condition `g'' = 0`, Rannacher start-up then Crank–Nicolson, and the modified
sparse-grid combination technique (base levels `ls` raised in the x1/x2
directions where the large mixed derivative lives). What changes for the GPU:

* **Matrix-free.** The 4-D operator (Theorem 7.3) is applied with slicing
  stencils on a tensor `(B, n1, n2, n3, n4)`; there are no sparse matrices and
  no LU factorisations (the CPU reference re-factorises `I − θΔt A(t)` every
  step because the coefficients are time dependent).
* **Batched.** Leading batch dimension over contracts; all reductions in the
  linear solver are per-batch.
* **Batched Jacobi-preconditioned BiCGSTAB** for the implicit steps. On these
  grids `σ²Δt/h² ≪ 1`, so `I − θΔt A` is a small perturbation of the identity and
  BiCGSTAB converges in 2–3 iterations to 1e-10.
* float64 by default; `dtype=torch.float32` for consumer GPUs; optional
  `compile=True` (torch.compile fuses the stencil kernels — worthwhile for long
  runs on large grids; it recompiles per sub-grid shape).

Validation: the CUDA and CPU solvers agree to ~1e-12 on identical grids; on
one CPU thread the torch solver is already ~2.5× faster than scipy for a single
contract and ~12× for a batch of five.

Throughput on a GPU is dominated by kernel-launch overhead (the sub-grids are
small — at most ~1e5 points), not by arithmetic: a full sparse-grid price for
a horizon of `T` years costs roughly `35 sub-grids × 96T steps × ~350 kernels`,
i.e. seconds per *batch*, independent of the batch size up to hundreds of
contracts. Batch as many contracts per horizon as you can. Possible further
optimisations (not done): CUDA graphs / `compile=True`, and running the ~35
independent sub-grids of the combination technique on concurrent streams.

## Notebooks — price grids over contractual parameters

Each notebook fixes the model (`p = ModelParams()`, edit to change), defines a
grid of contracts, prices it with the batched sparse-grid PDE on the GPU,
compares with the closed form / QMC / the paper, plots heatmaps and writes
`notebooks/results/<derivative>_grid.csv`.

| notebook | grid dimensions | reference |
|---|---|---|
| `01_bonds` | maturity T | closed form `e^{-f0 T}` (+ analytic surface `B(t,T,x)`) |
| `02_caplets` | fixing `TC` × strike `K` (`Δ` fixed) | closed form (eq. 20), errors in implied-vol points |
| `03_vanilla_swaps` | start `T0` × length `TN` × fixed rate `K` | analytic value / par rate / annuity / DV01 |
| `04_european_swaptions` | expiry `T0` × swap length `TN` × `K` | GPU Sobol QMC, paper Table 10 |
| `05_bermudan_swaptions` | `T0` × `TN` × `K`, semi-annual exercise | European (same grid), both exercise conventions, paper Table 11 |

Default settings are the paper's (`level=3, ls=(3,3,0,0), dt=1/96`);
`CHEYETTE_FAST=1` switches to coarse smoke-test grids. Headless execution:
`cd notebooks && python run_all.py` (or `jupyter nbconvert --execute`).
`04_european_swaptions.ipynb` ships executed at the default settings on a
single CPU thread (60 swaptions in 184 s; expect far less on a GPU); the other
four ship clean, validated end-to-end with `CHEYETTE_FAST=1`.

## Design choices

* **Quadrature instead of transcribed closed forms** for the caplet variance
  `v²` (A.2) and the forward-measure moments (28)–(35): the defining
  integrals are simple and adaptive quadrature is exact to machine precision.
  The closed-form `V` functions (A.1) *are* implemented and self-tested
  against quadrature (`model.selftest`, agreement ~1e-17).
* **Caplet PDE terminal condition**: Theorem 7.4's expression via the
  `K_i(X_i,T_C,T_B)` functions equals `max(1 − (1+KΔ)·B(T_C,T_B,x), 0)` with
  the analytic bond formula; the compact form is used.
* **Bermudan exercise** is applied as `g ← max(g, exercise value)` at the
  discrete exercise dates, equivalent to the PSOR/LCP treatment (E.1.3) when
  exercise is restricted to dates.
* **Swap convention** (matches paper Table 10): payments at `T0+tenor, …,
  T0+TN` (`TN` = swap *length*), floating leg `B(t,T0) − B(t,T0+TN)`.

## Validation (CPU reference code, paper settings)

| Test | Result |
|---|---|
| Closed-form V vs quadrature | agree to ~1e-17 |
| Analytic ATM caplets vs paper Table 5 | match to all printed digits |
| MC / Sobol QMC caplet vs analytic | 4e-6 (inside s.e.) / ~1e-7 |
| PDE bond B(0,2), level 2 | error 8e-6 |
| PDE caplet TC=1: ls=(2,2,0,0) → (3,3,0,0) → (4,4,0,0) | error 1.0e-3 → 4.7e-5 → 7.6e-6 (5.6% → 0.26% → 0.04% implied vol), the paper's Table 7 pattern |
| European swaption T0=1,TN=3,K=5%: PDE ls=3 | 0.011920 vs exact QMC 0.012245 (paper: PDE 0.011791, MC 0.011237) |
| PDE on linear payoffs (swaps) | reproduces the analytic value to 6+ digits |
| CUDA vs CPU solver, identical grids | 1e-12 |

## Review findings (deviations from / issues in the paper)

1. **Covariance of (X1, X2)** (pp. 51–53): the paper's
   `cov = c(a1 t²/2 + a0 t)` drops the mean-reversion kernel
   `exp(−λ⁽¹⁾(t−s))` of X2's stochastic integral, inconsistent with its own
   variance (33). Immaterial for λ⁽¹⁾ = −0.004; the exact form is used here.
2. **Bermudan early-exercise premium**: as the paper defines the contract
   ("the right to enter a *predefined* swap at several fixed dates", all
   before the swap start T0), the deflated forward-swap value is a
   Q^{T0}-martingale, so `max(V,0)` is a submartingale and the early-exercise
   premium is *exactly zero*. Our PDE and an independent Longstaff–Schwartz
   MC confirm ≈0. The paper's positive premia (Table 12, up to 4.3e-3)
   require an unstated "sliding" convention (exercise at t enters a TN-year
   swap starting at t) — implemented as `sliding=True`, which does give
   positive premia — or are numerical artifacts (their Bermudan PDE and MC
   disagree by up to 1.65e-3, the K=7% Bermudan is ~3× the European, and
   Figure 4's limit 0.01667 is inconsistent with Table 11's 0.056269).
3. **Calibrated λ's are negative** (Table 2): component volatilities *grow*
   with time to maturity; all formulas remain valid.
4. Minor typos (`B(t.TB)` in eq. 16, duplicated captions in Tables 7/9).

## Caveats

* Calibration (Section 5, simulated annealing to cap vols) is not
  re-implemented; parameters are hard-coded from Table 2.
* The Longstaff–Schwartz Bermudan MC (CPU, `montecarlo.py`) is a lower bound
  (sub-optimal exercise); the PDE is the primary Bermudan pricer.
