"""Quick throughput check of the CUDA sparse-grid solver.

    python bench_gpu.py            # paper settings, batch of 25 caplets
    python bench_gpu.py --fp32     # float32
"""
import sys, time, numpy as np, torch
from cheyette3f import *

p = ModelParams()
dtype = torch.float32 if "--fp32" in sys.argv else torch.float64
dev = get_device()
print("device:", device_info(), "| dtype:", dtype)
contracts = [Caplet(1.0, 2.0, K) for K in np.linspace(0.03, 0.07, 25)]
ref = price_analytic(p, contracts)
for B in (1, 5, 25):
    cs = contracts[:B]
    if dev.type == "cuda": torch.cuda.synchronize()
    t0 = time.time(); st = {}
    v = price_pde(p, cs, level=3, ls=(3, 3, 0, 0), dt=1 / 96, device=dev, dtype=dtype, stats=st)
    if dev.type == "cuda": torch.cuda.synchronize()
    dt_ = time.time() - t0
    print(f"batch {B:3d}: {dt_:6.1f}s  ({dt_/B:.2f}s per contract) | "
          f"max |err| vs closed form {np.max(np.abs(v - ref[:B])):.2e} | "
          f"BiCGSTAB iters/step {st['iters']/st['steps']:.2f}")
